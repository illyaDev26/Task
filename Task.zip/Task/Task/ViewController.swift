//
//  ViewController.swift
//  Task
//
//  Created by 1 on 15.12.2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstView: UIView!
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var thirdView: UIView!
    var views: [UIView] = []
    var counter = 0
    
    @IBOutlet weak var segmentedControll: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        views = [firstView,secondView,thirdView]
        
//        segmentedControll.selectedSegmentIndex = counter
//        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(handlegesture(gesture:)))
//        swipeleft.direction = .left
//        self.view.addGestureRecognizer(swipeleft)
//        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(handlegesture(gesture:)))
//        swipeleft.direction = .right
//        self.view.addGestureRecognizer(swiperight)
//
    self.view.bringSubviewToFront(firstView)

    }
    @objc func handlegesture(gesture:UISwipeGestureRecognizer){
        if counter >= 0 && counter < views.count{
           // if gesture.direction == UISwipeGestureRecognizer.Direction.right
          //  {
                if counter != 0 {
                    counter = counter - 1
                    self.view.bringSubviewToFront(views[counter])
                    segmentedControll.selectedSegmentIndex = counter
                }
                //}
            //if gesture.direction == UISwipeGestureRecognizer.Direction.left{
                if counter != views.count - 1 {
                    counter = counter - 1
                    segmentedControll.selectedSegmentIndex = counter
                    self.view.bringSubviewToFront(views[counter])

            }
        }
        }
    //}
    
    @IBAction func segmentAction(_ sender: UISegmentedControl) {
        self.view.bringSubviewToFront(views[sender.selectedSegmentIndex])
        counter = segmentedControll.selectedSegmentIndex
    }
}
 
    

