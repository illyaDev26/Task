//
//  Movie.swift
//  Task
//
//  Created by 1 on 16.12.2021.
//


//{
//  "page": 1,
//  "results": [
//    {
//      "poster_path": "/9O7gLzmreU0nGkIB6K3BsJbzvNv.jpg",
//      "adult": false,
//      "overview": "Framed in the 1940s for the double murder of his wife and her lover, upstanding banker Andy Dufresne begins a new life at the Shawshank prison, where he puts his accounting skills to work for an amoral warden. During his long stretch in prison, Dufresne comes to be admired by the other inmates -- including an older prisoner named Red -- for his integrity and unquenchable sense of hope.",
//      "release_date": "1994-09-10",
//      "genre_ids": [
//        18,
//        80
//      ],
//      "id": 278,
//      "original_title": "The Shawshank Redemption",
//      "original_language": "en",
//      "title": "The Shawshank Redemption",
//      "backdrop_path": "/xBKGJQsAIeweesB79KC89FpBrVr.jpg",
//      "popularity": 6.741296,
//      "vote_count": 5238,
//      "video": false,
//      "vote_average": 8.32
//    }

import Foundation

struct Moview {
    var poster_path :String
    var adult:String
    var release_date:String
    
    init (dictionary: Dictionary<String,Any>){
        poster_path = dictionary["author"]as? String ?? ""
        adult = dictionary["author"]as? String ?? ""
        release_date = dictionary["author"]as? String ?? ""
}
}
