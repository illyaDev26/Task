//
//  model.swift
//  Task
//
//  Created by 1 on 16.12.2021.
//

import Foundation

var movies: [Moview] = []
var urlData: URL {
    let path = NSSearchPathForDirectoriesInDomains(.libraryDirectory,.userDomainMask, true)[0] + "/data.json"
    let urlPath = URL(fileURLWithPath: path)
    return urlPath

}
func loadMovies(completionHandler: (()-> Void)?) {
    let url = URL(string: "https://api.themoviedb.org/3/movie/top_rated?api_key=f910e2224b142497cc05444043cc8aa4&language=en-US&page=1")
    let session = URLSession(configuration: .default)
    
    let  dowloadTask = session.downloadTask(with: url!) { (urlFile,response,error) in

        if urlFile  != nil {
            
            try? FileManager.default.copyItem(at: urlFile!, to: urlData)
             debugPrint(urlData)
            parceMoview()
             debugPrint(movies.count)
            completionHandler?()
//        }else{
//            return
//        }
        }
    }
    dowloadTask.resume()
}
func parceMoview() {

    let data = try? Data(contentsOf: urlData)
    if data == nil {
        return
    }
    
    
    let rootDictAny = try? JSONSerialization.jsonObject(with: data! , options: .allowFragments) as? Dictionary<String,Any>
    if rootDictAny == nil {
        return
    }
    
    let  rootDict = rootDictAny
    if rootDict == nil {
    return
    }
    
    
    if  let array = rootDict!["movies"] as? [Dictionary<String, Any>]{
        var returnArray: [Moview] = []
        for dict in array {
            let newArticle = Moview(dictionary: dict)
            returnArray.append(newArticle)
    }
    
        movies = returnArray
    }
   
}




